from django.core.exceptions import ValidationError
from django.core.validators import EmailValidator, URLValidator
from django.db import models as m

md = m.Model


# Custom Validators
def letter_space_check(value):
    if not all(char.isalpha() or char.isspace() for char in value):
        raise ValidationError('Name can only contain letters and spaces')


def age_check(value):
    if value < 18:
        raise ValidationError('Age must be greater than or equal to 18')


def phone_check(value):
    if value[:4] != '+359' or len(value) != 13:
        raise ValidationError("Phone number must start with '+359' followed by 9 digits")


# Create your models here.
class Customer(md):
    name = m.CharField(
        max_length=100,
        validators=[letter_space_check]
    )

    age = m.PositiveIntegerField(
        validators=[age_check]
    )

    email = m.EmailField(
        error_messages={
            'invalid': 'Enter a valid email address'
        }
    )

    phone_number = m.CharField(
        max_length=13,
        validators=[phone_check]
    )

    website_url = m.URLField(
        error_messages={
            'invalid': 'Enter a valid URL'
        }
    )


