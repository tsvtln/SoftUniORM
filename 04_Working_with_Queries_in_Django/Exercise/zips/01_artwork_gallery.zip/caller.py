import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import ArtworkGallery


# from dummy_data import populate_model_with_data
#
# populate_model_with_data(ArtworkGallery)

def show_highest_rated_art() -> str:
    all_arts = ArtworkGallery.objects.all().order_by('-rating', 'id').first()
    return f"{all_arts.art_name} is the highest-rated art with a {all_arts.rating} rating!"


def bulk_create_arts(first_art: ArtworkGallery, second_art: ArtworkGallery) -> None:
    ArtworkGallery.objects.bulk_create([
        first_art,
        second_art,
    ])


def delete_negative_rated_arts() -> None:
    ArtworkGallery.objects.filter(rating__lt=0).delete()



# print(show_highest_rated_art())
